   <div id="pied"> 
    <hr>
      <p>&copy; ailTECH </p>
      <p>Lycée Pierre Poivre <a href="#"> BTS-SIO</a></p>
      <button onclick="imprimPage()">Imprimer la page</button>
      <script>
		function imprimPage() {
    	window.print();
		}
		</script>
   </div>
</body>
</html>