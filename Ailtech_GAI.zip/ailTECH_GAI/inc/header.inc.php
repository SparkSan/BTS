<!DOCTYPE html>
<html lang="fr">
<head>
      <meta charset="UTF-8">
      <title>GestImmo</title>
      <link rel="stylesheet" type="text/css" media="screen" href="../asset/style.css">
      <link rel="stylesheet" type="text/css" media="print" href="../asset.impression.css">
      <script language=javascript src="../asset/mesfonctions.js"></script>
   </head>
   <body>
      <div id="entete">
         <a href="../index.php"><img class="logo" src="../images/logo.png" alt="logo"></a>
         <h1  font-family:'Arial' font-size='48pt'>Gestion Agence Immobilière</h1>
      </div>
      <hr>
