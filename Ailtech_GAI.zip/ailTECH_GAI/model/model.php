<?php
include("daoImmo.php");

//---------------------------------------------------------------------
class Model{

private	$monDao;

//---------------------------------------------------------------------
function __construct()
	{
	$this->monDao=new DaoImmo();
	}
//---------------------------------------------------------------------
function getAllOrderBy($ordre)
	{
	return $this->monDao->getAllOrderBy($ordre);
	}
//---------------------------------------------------------------------
function getAllByVille($ville)
	{
	return $this->monDao->getAllByVille($ville);
	}
//---------------------------------------------------------------------
function getAllById($id)
	{
	return $this->monDao->getAllById($id);
	}
//---------------------------------------------------------------------
function getVilleByVilleStartWith($ville)
	{
	$t=$this->monDao->getVilleByVilleStartWith($ville);
	return $t;
	}

 function getMaxi()
 	{
 	$t=$this->monDao->getMaxi();
	return $t;
 	}

 function getMini()
 	{
 	$t=$this->monDao->getMini();
	return $t;
 	}

 function getMoy()
 	{
 	$t=$this->monDao->getMoy();
	return $t;
 	}

 function getBudInf($budget)
 {
 $t=$this->monDao->getBudInf($budget);
 return $t;
 }

 function getBudGenre($budget, $genre)
 {
 $t=$this->monDao->getBudGenre($budget, $genre);
 return $t;
 }

  function getBudSupMoy()
 {
 $t=$this->monDao->getBudSupMoy();
 return $t;
 }

  function getNbBiens()
 {
 $t=$this->monDao->getNbBiens();
 return $t;
 }

};// fin de classe

?>
