<?php
include ("MyPDO.php");
//*****************************************************************************************
class DaoImmo extends MyPDO
{

	// constructeur qui appelle constructeur de la super classe qui effectue la connexion
	// avec les variables contenues dans login.php
    function __construct()
	{
	include ("login.php");
	parent::__construct('mysql:host='.$serveur.';dbname='.$mabase,$login, $motdepasse);
    } // fin constructeur
//---------------------------------------------------------------------
  function getAllOrderBy($ordre)
	{ 
	//echo "Ordre : ".$ordre."<br>";
	$strSQL = "SELECT idDemande, idPersonne,	genre, ville, budget, superficie FROM demande order by ".$ordre;
	$getAllOrderBy=$this->prepare($strSQL);
	$getAllOrderBy->execute();
	$t=$getAllOrderBy->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}
//---------------------------------------------------------------------
	function getAllByVille($ville)
	{//http://php.net/manual/fr/pdostatement.execute.php
	$getAllByVille=$this->prepare("SELECT * FROM demande WHERE ville= ?");
	$getAllByVille->execute(array($ville));
	$t=$getAllByVille->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}
//---------------------------------------------------------------------
	function getAllById($id)
	{
	$getAllById=$this->prepare("SELECT * FROM demande WHERE idDemande = ?");
	$getAllById->execute(array($id));
	$t=$getAllById->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}
//---------------------------------------------------------------------
	function getVilleByVilleStartWith($ville)
	{
	$getVilleByVilleStartWith=$this->prepare("SELECT distinct ville FROM demande WHERE ville like ? ");
	$ville=$ville.'%';
	$retour=array();
	$getVilleByVilleStartWith->setFetchMode(PDO::FETCH_NUM);
	$getVilleByVilleStartWith->execute(array($ville));
	for ($i=0;$i<$getVilleByVilleStartWith->rowCount();$i++)
		{
		$retour=array_merge($retour,$getVilleByVilleStartWith->fetch());
		}
	return $retour;
	}
//---------------------------------------------------------------------
		function getMaxi()
	{
	$strSQL =("SELECT MAX(budget) AS 'Budget maximum' FROM demande ");
	$getMaxi=$this->prepare($strSQL);
	$getMaxi->execute(array());
	$t=$getMaxi->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}
//---------------------------------------------------------------------
			function getMini()
	{
	$getMini=$this->prepare("SELECT MIN(budget) AS 'Budget minimum' FROM demande ");
	$getMini->execute(array());
	$t=$getMini->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}
//---------------------------------------------------------------------
			function getMoy()
	{
	$getMoy=$this->prepare("SELECT AVG(budget) AS 'Budget moyen' FROM demande ");
	$getMoy->execute(array());
	$t=$getMoy->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}
//---------------------------------------------------------------------
			function getBudInf($budget)
	{
	$getBudInf=$this->prepare("SELECT * FROM demande WHERE budget < ?");
	$getBudInf->execute(array($budget));
	$t=$getBudInf->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}

				function getBudGenre($budget, $genre)
	{
	$getBudGenre=$this->prepare("SELECT * FROM demande WHERE budget < ? AND genre = ? ");
	$getBudGenre->execute(array($budget, $genre));
	$t=$getBudGenre->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}

				function getBudSupMoy()
	{
	$getBudSupMoy=$this->prepare("SELECT * FROM demande WHERE budget > ( SELECT AVG( budget ) AS  'Budget moyen' FROM demande )");
	$getBudSupMoy->execute(array());
	$t=$getBudSupMoy->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}

			function getNbBiens()
	{
	$getNbBiens=$this->prepare("SELECT COUNT(*) AS 'Nombre de biens' FROM demande ");
	$getNbBiens->execute(array());
	$t=$getNbBiens->fetchAll(PDO::FETCH_OBJ);
	return $t;
	}


};// fin de classe
