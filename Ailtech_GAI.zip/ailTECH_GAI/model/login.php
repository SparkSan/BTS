<?php
 $serveur='localhost';
 $login="root";
$motdepasse="btssio";
 $mabase="Ailtech_GAI";

?>
