<?php
      $start_view = 'demande';
      echo $start_view ;
      header('Location:./control/controller.php');
?>